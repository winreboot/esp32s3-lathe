Interface board rev F as Gerber + Excellon files, for PCB CAM programs such as FlatCAM. These are not DXF files:
for DXF or SVG CAM use board_revF_bottom.dxf and board_revF_top.dxf (or the .svg versions).

Two-sided board, no plated holes. Both coppers are drawn viewed from the top, as Gerber requires,
so mirror the bottom (B_Cu) when you mill it copper side up. The drill file includes the two
3.0 mm alignment holes on the flip line x = 72.0. The edge cuts include the 2.0 mm wide slot
under U1: cut it with an end mill of 1.5 mm or less.

Units mm. Drill sizes: 0.8 mm, 1.3 mm, 3.0 mm
